const BASE_URL = "http://localhost:8000/api";

function getCookie(name) {
  let cookieValue = null;
  if (document.cookie && document.cookie !== '') {
    const cookies = document.cookie.split(';');
    for (let i = 0; i < cookies.length; i++) {
      const cookie = cookies[i].trim();
      if (cookie.substring(0, name.length + 1) === (name + '=')) {
        cookieValue = decodeURIComponent(cookie.substring(name.length + 1));
        break;
      }
    }
  }
  return cookieValue;
}

async function request(url, options = {}) {
  const csrftoken = getCookie('csrftoken');
  const res = await fetch(`${BASE_URL}${url}`, {
    credentials: "include", 
    headers: { 
      "Content-Type": "application/json",
      "X-CSRFToken": csrftoken,
      ...(options.headers || {}) 
    },
    ...options,
  });
  
  const data = await res.json().catch(() => ({}));
  if (!res.ok) {
    const err = new Error(data.message || "Ошибка запроса");
    err.data = data;
    err.status = res.status;
    throw err;
  }
  return data;
}

export function fetchProperties(params = {}) {
  const query = new URLSearchParams(params).toString();
  return request(`/properties/${query ? "?" + query : ""}`);
}

export function fetchPropertyTypes() {
  return request("/property-types/");
}

export function createProperty(payload) {
  return request("/properties/", { method: "POST", body: JSON.stringify(payload) });
}

export function createViewingRequest(payload) {
  const safeDate = (payload.preferred_date && payload.preferred_date.trim() !== "") ? payload.preferred_date : null;
  const dataToSend = {
    property_id: payload.property, 
    name: payload.name,
    phone: payload.phone,
    comment: payload.comment || "",
    preferred_date: safeDate
  };
  return request("/requests/", { method: "POST", body: JSON.stringify(dataToSend) });
}

export function fetchRequests() {
  return request("/requests/");
}

export function fetchAgents() {
  return request("/agents/");
}

export function fetchBlogPosts() {
  return request("/blog/");
}

export function login(username, password) {
  return request("/login/", {
    method: "POST",
    body: JSON.stringify({ username, password }),
  });
}

export function register(username, password, firstName) {
  return request("/register/", {
    method: "POST",
    body: JSON.stringify({ username, password, first_name: firstName }),
  });
}

export function logout() {
  return request("/logout/", { method: "POST" });
}

export function fetchCurrentUser() {
  return request("/current-user/");
}